import javax.swing.*;

public class MusicPlayer {
    public static void play(String filePath) {
        JOptionPane.showMessageDialog(null, "Pretending to play:\n" + filePath);
        // Optionally use JavaFX MediaPlayer for actual audio
    }
}

