import javax.swing.SwingUtilities;

public class MoodTunesApp {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MoodTunesGUI());
    }
}
